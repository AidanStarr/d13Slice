function s=d13slice(latlim,lonlim,varargin)
clf
if exist('d13.mat')==0
    warning('Missing data... What am I supposed to do, create a beautiful d13C visualization from scratch?! See readme file for link to data. If you have the data, add it to your working directory and name it d13.mat')
    return
end
if exist('bathy.txt')==0
    warning('Could not find bathymetry file "worldbath5.nc". Please ensure file is downloaded, added to working directory and named as "worldbath5.nc".')
    return
end
if lonlim(2)>180
    warning('Please use longitude limits between -180 and 180!')
    return
end


%Get the data in shape and ready for plotting
%First, the d13C data, which should be in your cd.
d13=open('d13.mat');
d13=d13.ans;
%construct the lat-lon-depth parameter space
lat=[-89.5000:1:89.5]';
lon=[-180:1:179.5;]';
dep=[0:10:30 50 75:25:150 200:50:300 400:100:1500 1750 2000:500:5500]'; 
d132=d13(1:180,:,:);
d131=d13(181:360,:,:);
d13=[d131; d132];
d13=permute(d13,[2,1,3]);


%Now let's prepare the bathymetry data (this should have come in the folder
%with the function!
xx=load('xx.txt');
yy=load('yy.txt');
bath=load('bathy.txt');
bathh=permute(bath,[2,1,3]);
bathh(bathh>300)=300;
bathhh=fliplr(bathh);
bathhh(bathhh>300)=300;

%Before we move on, I'll follow my mother's ever-prescient advice and TIDY
%THE HELL UP (I should just write tidier code...)
clearvars -except bathh bathhh xx yy lat lon dep d13 latlim lonlim

%okay now for the function
%Did the user want to dissect their plot?
if nargin==2
    a=lonlim(1);
b=lonlim(2);
c=latlim(1);
d=latlim(2);
aa=find(lon>a,1);
bb=find(lon>b,1);
cc=find(lat>c,1);
dd=find(lat>d,1);

sl1=single(d13(cc:dd,aa:bb,:));
latt=lat(cc:dd);
lonn=lon(aa:bb);
d1=dep(10);
zslice=d1;
zslice=single(zslice);
yslice=[min(latt),median(latt)-0.1*median(latt),median(latt)+0.1*median(latt),max(latt)];
yslice=single(yslice);
xslice=[min(lonn),max(lonn)];
xslice=single(xslice);

%prepare meshgrid for plotting
[x,y,z]=meshgrid(lonn,latt,dep);
x=single(x);
y=single(y);
z=single(z);

%plot! well, some of it.
s=slice(x,y,z,sl1,xslice,yslice,zslice);
set(gca,'zdir','reverse')
set(gca,'ydir','normal')
set(s,'EdgeColor','none')
cb=colorbar;
set(cb,'position',[0.8616    0.1100    0.0260    0.3450]);
ylabel(cb,'\delta^1^3C');
hold on
%cs=contourslice(x,y,z,sl1,xslice,yslice,single([]),30);
%set(cs,'edgecolor',rgb('grey'),'linewidth',0.1)
shading interp

%plot the bathymetry
hold on
sur=surf(xx,yy,-bathh);
sur2=surf(-xx,yy,-bathhh);
zlim([-2000 7000])
xlim([a-5,b+5])
ylim([c-5,d+5])

%colors and lighting
set(sur,'EdgeColor','none')
set(sur,'FaceAlpha',1)
set(sur2,'EdgeColor','none')
set(sur2,'FaceAlpha',1)
set(sur2,'FaceColor',[0.5725    0.5843    0.5686])
set(sur,'FaceColor',[0.5725    0.5843    0.5686])
light
set(sur,'FaceLighting','gouraud')
set(sur2,'FaceLighting','gouraud')
set(s,'FaceLighting','none')
axis off
colorcet('R1')
caxis([-0.3 2])
alpha(0.92)
end

%okay now the hard bit... the user wants to dissect!
if nargin~=2
    
    a=lonlim(1);
b=lonlim(2);
a1=[a,a+0.4*range(lonlim)];
a3=[(b-0.4*range(lonlim)),b];
a2=[max(a1),min(a3)];
c=latlim(1);
d=latlim(2);
c2=[c+0.5*range(latlim),d];

%d13c plot 1
aa1=find(lon>a1(1),1);
bb1=find(lon>a1(2),1);
cc1=find(lat>c,1);
dd1=find(lat>d,1);

sl1=single(d13(cc1:dd1,aa1:bb1,:));
latt1=lat(cc1:dd1);
lonn1=lon(aa1:bb1);
d1=dep(10);
zslice=d1;
zslice=single(zslice);
yslice1=[min(latt1),max(latt1)];
yslice1=single(yslice1);
xslice1=[min(lonn1),max(lonn1)];
xslice1=single(xslice1);

[x1,y1,z1]=meshgrid(lonn1,latt1,dep);
x1=single(x1);
y1=single(y1);
z1=single(z1);

v=[-0.5 0 0.5 1 1.5 2];

s1=slice(x1,y1,z1,sl1,xslice1,yslice1,zslice);
%cs1=contourslice(x1,y1,z1,sl1,xslice1,yslice1,zslice,v)
%set(cs1,'edgecolor','k')
%set(cs1,'edgealpha',0.5)
set(gca,'zdir','reverse')
set(gca,'ydir','normal')
set(s1,'EdgeColor','none')
shading interp
cb=colorbar;
ylabel(cb,'\delta^1^3C');
set(cb,'position',[0.8616    0.1100    0.0260    0.3450]);
hold on

%d13c plot 2
aa2=find(lon>a2(1),1);
bb2=find(lon>a2(2),1);
cc2=find(lat>c2,1);
dd2=find(lat>d,1);

sl2=single(d13(cc2:dd2,aa2:bb2,:));
latt2=lat(cc2:dd2);
lonn2=lon(aa2:bb2);
d1=dep(10);
zslice=d1;
zslice=single(zslice);
yslice2=[min(latt2),max(latt2)];
yslice2=single(yslice2);
xslice2=[min(lonn2),max(lonn2)];
xslice2=single(xslice2);

[x2,y2,z2]=meshgrid(lonn2,latt2,dep);
x2=single(x2);
y2=single(y2);
z2=single(z2);

s2=slice(x2,y2,z2,sl2,xslice2,yslice2,zslice);
%cs2=contourslice(x2,y2,z2,sl2,xslice2,yslice2,zslice,v)
%set(cs2,'edgecolor','k')
%set(cs2,'edgealpha',0.5)
set(gca,'zdir','reverse')
set(gca,'ydir','normal')
set(s2,'EdgeColor','none')
shading interp
hold on

%d13 plot 3
aa3=find(lon>a3(1),1);
bb3=find(lon>a3(2),1);
cc3=find(lat>c,1);
dd3=find(lat>d,1);

sl3=single(d13(cc3:dd3,aa3:bb3,:));
latt3=lat(cc3:dd3);
lonn3=lon(aa3:bb3);
d1=dep(10);
zslice=d1;
zslice=single(zslice);
yslice3=[min(latt3),max(latt3)];
yslice3=single(yslice3);
xslice3=[min(lonn3),max(lonn3)];
xslice3=single(xslice3);

[x3,y3,z3]=meshgrid(lonn3,latt3,dep);
x3=single(x3);
y3=single(y3);
z3=single(z3);

s3=slice(x3,y3,z3,sl3,xslice3,yslice3,zslice);
%cs3=contourslice(x3,y3,z3,sl3,xslice3,yslice3,zslice,v)
%set(cs3,'edgecolor','k')
%set(cs3,'edgealpha',0.5)
set(gca,'zdir','reverse')
set(gca,'ydir','normal')
set(s3,'EdgeColor','none')
shading interp
hold on
%cs=contourslice(x,y,z,sl1,xslice,yslice,single([]),30);
%set(cs,'edgecolor',rgb('grey'),'linewidth',0.1)


%now finally plot bathymetry

hold on
sur=surf(xx,yy,-bathh);
sur2=surf(-xx,yy,-bathhh);
zlim([-2000 7000])
xlim([a-5,b+5])
ylim([c-5,d+5])

set(sur,'EdgeColor','none')
set(sur,'FaceAlpha',1)
set(sur2,'EdgeColor','none')
set(sur2,'FaceAlpha',1)
set(sur2,'FaceColor',[0.5725    0.5843    0.5686])
set(sur,'FaceColor',[0.5725    0.5843    0.5686])
light
set(sur,'FaceLighting','gouraud')
set(sur2,'FaceLighting','gouraud')
set(s1,'FaceLighting','none')
set(s2,'FaceLighting','none')
set(s3,'FaceLighting','none')
axis off
colorcet('R1')
caxis([-0.3 2])
alpha(sur,0.88)
alpha(sur2,0.88)
alpha(s1,0.9)
alpha(s2,0.9)
alpha(s3,0.9)

end
if nargin>3 
    warning('Hmmm. Looks like we cannot handle more than one dissection atm, check back for an update')
end

end

